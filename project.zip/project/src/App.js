import React from "react";
import Header from './pages/home/header'
import Hero from './pages/home/hero'
function App() {
  return (
    <div >
     <Header />
     <Hero />
    </div>
  );
}

export default App;
