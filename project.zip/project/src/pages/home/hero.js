import React from 'react'
import AutoTyping, { BlinkCursor } from 'react-auto-typing'
import Hero from '../../assets/image/portrait.jpg'
function hero() {
  return (
    <div>


<div className='bg-image'>
      <img src={Hero} className='img-fluid' alt='Sample' />
      <div className='mask' style={{ backgroundColor: '222, 222, 222' }}>
        <div className='fs-3' style={{ marginTop:"150px", color:"white" }} dir='rtl'>
        <AutoTyping
      active // <boolean>
      textRef= {'سلام من حسین اسدی fullstack developer این سایت شخصی من است' + 'dfsfklsjfskldf'}
      writeSpeed={150} // <number>
      deleteSpeed={150} // <number>
      delayToWrite={1000} // <number>
      delayToDelete={2000} // <number>
    />
    
    <BlinkCursor
      active // <boolean>
      blinkSpeed={500} // <number>
    /> 
        </div>
      </div>
    </div>


    </div>
  )
}

export default hero
